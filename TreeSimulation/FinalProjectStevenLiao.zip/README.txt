Steven Liao
108607000
CSE 328 Final Project README

This project is done in Xcode.

In order to work this program, you need to go into main.cpp and change the line in which the file path is inputted. The changed line should be in the main method of the main.cpp. The path is absolute to my computer so you would have to change the path to point to Extreme-Alpha.png.